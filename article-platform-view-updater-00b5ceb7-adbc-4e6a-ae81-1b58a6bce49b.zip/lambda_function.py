import json
import os
import pg8000

def update_view_count(article_id):
    conn = pg8000.connect(
        host=os.environ["DB_HOST"],
        database=os.environ["DB_NAME"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"]
    )

    cursor = conn.cursor()

    cursor.execute("""
        UPDATE article_view_counts
        SET view_count = view_count + 1
        WHERE article_id = %s
    """, (article_id,))

    conn.commit()

    cursor.close()
    conn.close()


def lambda_handler(event, context):

    # event["Records"] contains the SQS messages
    for record in event["Records"]:

        message = json.loads(record["body"])

        if message["type"] != "VIEW":
            continue

        update_view_count(message["articleId"])

    return {
        "statusCode": 200
    }